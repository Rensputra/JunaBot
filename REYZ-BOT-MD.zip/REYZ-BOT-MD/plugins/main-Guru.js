let handler = async m => m.reply(`

https://chat.whatsapp.com/Em4vPwiN7151mO3lDpkdrm

`.trim())
handler.help = ['gpguru']
handler.tags = ['main']
handler.command = ['groups', 'groupguru', 'gugp', 'ggp', 'gpguru'] 

export default handler
